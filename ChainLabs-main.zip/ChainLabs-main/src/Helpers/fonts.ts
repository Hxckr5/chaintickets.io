import localFont from "next/font/local";
// const myFont = localFont({ src: './Gilroy.ttf' })
const reg = localFont({ src: "./fonts/Realreg.otf" });

export const Reg = reg;


